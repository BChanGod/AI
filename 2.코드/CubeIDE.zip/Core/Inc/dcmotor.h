#ifndef __DCMOTOR_H__
#define __DCMOTOR_H__
void DCMOTOR_Init();
void DCMOTOR_ON();
void DCMOTOR_OFF();
#endif 
